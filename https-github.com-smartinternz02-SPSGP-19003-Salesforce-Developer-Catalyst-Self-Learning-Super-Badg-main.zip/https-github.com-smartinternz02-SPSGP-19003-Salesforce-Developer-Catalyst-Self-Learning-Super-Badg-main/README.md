# https-github.com-smartinternz02-SPSGP-19003-Salesforce-Developer-Catalyst-Self-Learning-Super-Badges
# SPSGP-19003-Salesforce-Developer-Catalyst-Self-Learning-Super-Badges
# Salesforce Developer Catalyst Self-Learning &amp -->

https://trailhead.salesforce.com/en/users/trailblazerconnect/trailmixes/salesforce-developer-catalyst

# Apex Triggers Module -->  

https://trailhead.salesforce.com/en/content/learn/modules/apex_triggers

# Apex Testing -->  

https://trailhead.salesforce.com/content/learn/modules/apex_testing

# Asynchronous Apex --> 

https://trailhead.salesforce.com/en/content/learn/modules/asynchronous_apex

# Apex Integration Services --> 

https://trailhead.salesforce.com/en/content/learn/modules/apex_integration_services

# Super Badges : 
# 1. Apex Specialist Superbadges:

https://trailhead.salesforce.com/content/learn/superbadges/superbadge_apex?trailmix_creator_id=trailblazerconnect&trailmix_slug=salesforce-developer-catalyst

# 2. Process Automation Specialist: 

https://trailhead.salesforce.com/content/learn/superbadges/superbadge_process_automation?trailmix_creator_id=trailblazerconnect&trailmix_slug=salesforce-developer-catalyst
